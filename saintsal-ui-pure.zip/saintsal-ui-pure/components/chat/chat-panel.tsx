'use client'

export function ChatPanel({ locale, workspaceid, chats, refreshChats }: any) {
  return <div className="flex-1">Chat Panel ({locale})</div>
}

