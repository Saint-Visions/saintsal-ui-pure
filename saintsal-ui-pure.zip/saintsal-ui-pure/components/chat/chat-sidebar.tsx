'use client'

export function ChatSidebar({ workspaceid, chats, refreshChats }: any) {
  return <div className="w-64">Sidebar for {workspaceid}</div>
}

